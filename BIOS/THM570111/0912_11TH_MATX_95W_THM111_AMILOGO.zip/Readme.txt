Warning: Updating the BIOS maybe will bring you the potential risk. Please be careful. During the execution of the BIOS upgrade process, please do not remove the removable device or turn off or restart it, which will cause the motherboard can not start.

For 11TH generation motherboards and ES motherboards, you need to  press the Delete key to enter the BIOS to confirm the motherboard version is THM570106 or THM570306, then upgrade the corresponding BIOS file.Or if you upgrade the wrong BIOS file which will cause the motherboard can not start.

Following are the steps of upgrading the Bios：

1. Format the USB flash disk into a FAT32 partition, do not use MSDOS or other boot disks

2. Unzip the downloaded BIOS profile to the root directory of the USB flash disk

3. Insert the USB flash disk into the USB interface of the motherboard , and without connecting all SATA and M.2 SSD devices

4.Press the power button and wait a moment. The motherboard will enter the UEFI shell page and will upgrade the BIOS automatically 

5.Wait for 1-3 minutes,until you see the green words showing "SUCCESS" ,then you can turn off PC

6.After upgrading the BIOS, we suggest you to turn off the AC power supply for the motherboard, clear the CMOS, and then press the Delete key to enter the BIOS,next to press F9 key to load the optimized value, finally press F10 key to save and restart.       

7.Upgrade completed       